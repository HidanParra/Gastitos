<?php
require_once 'Medoo.php';

use Medoo\Medoo;

$db = new Medoo([
    'database_type' => 'mysql',
    'database_name' => 'softengi_daniel',
    'server' => 'softenginesolutions.com.mx',
    'username' => 'softengi_hashi',
    'password' => 'P@ndidill0'
]);

?>
